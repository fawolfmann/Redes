#!/bin/bash
#delete
sudo docker exec -it pc2_r4_1 ip -6 route del default via 2001:bbbb:4444::1
sudo docker exec -it pc2_r6_1 ip -6 route del default via 2001:bbbb:6666::1
sudo docker exec -it pc2_r8_1 ip -6 route del default via 2001:bbbb:6688::1
sudo docker exec -it pc2_b2_1 ip -6 route del default via 2001:bbbb:cccc::1
sudo docker exec -it pc2_h12_1 ip -6 route del default via 2001:bbbb:6666::1
sudo docker exec -it pc2_h14_1 ip -6 route del default via 2001:bbbb:8888::1

#add para hosts
sudo docker exec -it pc2_h12_1 ip -6 route add default via 2001:bbbb:6666::16
sudo docker exec -it pc2_h14_1 ip -6 route add default via 2001:bbbb:8888::18

echo "Listo delete default route PC2"
