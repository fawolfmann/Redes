sudo docker exec -it pc2_dns_1 apt-get update
sudo docker exec -it pc2_dns_1 apt-get upgrade
sudo docker exec -it pc2_dns_1 apt-get install libsocket6-perl
sudo docker exec -it pc2_dns_1 /etc/webmin/restart
sudo docker exec -it pc2_dns_1 apt-get install nano
echo "Script... OK"