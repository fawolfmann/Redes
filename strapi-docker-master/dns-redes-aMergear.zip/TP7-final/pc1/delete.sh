#!/bin/bash
#delete
sudo docker exec -it pc1_r3_1 ip -6 route del default via 2001:aaaa:3333::1
sudo docker exec -it pc1_r5_1 ip -6 route del default via 2001:aaaa:5555::1
sudo docker exec -it pc1_r7_1 ip -6 route del default via 2001:aaaa:5577::1
sudo docker exec -it pc1_b1_1 ip -6 route del default via 2001:aaaa:cccc::1
sudo docker exec -it pc1_h11_1 ip -6 route del default via 2001:aaaa:5555::1
sudo docker exec -it pc1_h13_1 ip -6 route del default via 2001:aaaa:7777::1

#add para hosts
sudo docker exec -it pc1_h11_1 ip -6 route add default via 2001:aaaa:5555::15
sudo docker exec -it pc1_h13_1 ip -6 route add default via 2001:aaaa:7777::17

echo "Listo delete default route PC1"
